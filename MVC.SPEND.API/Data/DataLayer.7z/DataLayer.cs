﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Data;
using System.Threading;
using System.Threading.Tasks;

namespace MVC.SPEND.API.Data
{

    public class DataLayer
    {
        private bool disposed = false;
        private string WMsg = ".";
        private int SSAccDB = int.Parse(ConfigurationManager.AppSettings["SSAccDB"]);
        private object RD;

        private string DevRootDB()
        {
            string WSDB = ConfigurationManager.AppSettings["SQLServer"];
            string WProv = ConfigurationManager.AppSettings["OLEDBProv"];
            string WProp = ConfigurationManager.AppSettings["OLEDBProp"];
            var WPath = HttpContext.Current.Server.MapPath("\\DB");
            string WDB = WProv + WPath + WProp;
            return SSAccDB == 0 ? WSDB : WDB;
        }

        public async Task<IDataReader> FNReader(string WSP, int nData, string WPar, params string[] oVal)
        {
            if (SSAccDB == 0)
            {
                return await FNRdr(WSP, nData, WPar, oVal);
            }
            else
            {
                return await FNRdr(1, WSP, nData, WPar, oVal);
            }
        }
        private SqlCommand FNCMDExeSP(string WSP, int nData, string WPar, params string[] oVal)
        {
            char CLim = '|'; string[] oPars = WPar.Split(CLim); int K = 0;
            string WDB = DevRootDB();
            SqlConnection DB = new SqlConnection(WDB); DB.Open(); SqlCommand cmd = DB.CreateCommand(); cmd.CommandText = WSP;
            cmd.CommandType = CommandType.StoredProcedure;
            foreach (var val in oVal)
            {
                cmd.Parameters.AddWithValue(oPars[K], oVal[K]); K++;
            }
            Array.Clear(oPars, 0, oPars.Length); oPars = null; Array.Clear(oVal, 0, oVal.Length); oVal = null;
            return cmd;
        }
       
        private OleDbCommand FNCMDExeSP(int EsAccess, string WSP, int nData, string WPar, params string[] oVal)
        {
            char CLim = '|'; string[] oPars = WPar.Split(CLim); int K = 0;
            string WPath = DevRootDB();
            OleDbConnection DB = new OleDbConnection(WPath); DB.Open(); OleDbCommand cmd = DB.CreateCommand(); cmd.CommandText = WSP;
            cmd.CommandType = CommandType.StoredProcedure;
            foreach (var val in oVal)
            {
                cmd.Parameters.AddWithValue(oPars[K], oVal[K]); K++;
            }
            Array.Clear(oPars, 0, oPars.Length); oPars = null; Array.Clear(oVal, 0, oVal.Length); oVal = null;
            return cmd;
        }
        private async Task<SqlDataReader> FNRdr(string WSP, int nData, string WPar, params string[] oVal)
        {
            SqlCommand cmd = FNCMDExeSP(WSP, nData, WPar, oVal);
            if (nData == 1)
            {
                cmd.ExecuteNonQuery(); return null;
            }
            return cmd.ExecuteReader(CommandBehavior.CloseConnection);
        }
        private async Task<OleDbDataReader> FNRdr(int EsAccess, string WSP, int nData, string WPar, params string[] oVal)
        {
            OleDbCommand cmd = FNCMDExeSP(1, WSP, nData, WPar, oVal);
            if (nData == 1)
            {
                cmd.ExecuteNonQuery(); return null;
            }
            return cmd.ExecuteReader(CommandBehavior.CloseConnection);
        }
        public async Task<DataTable> FNFillReader(string WSP, string WPar, params string[] oVal)
        {
            DataTable ds = new DataTable();
            if (SSAccDB == 0)
            {
                SqlDataAdapter da = await FNFillRead(WSP, WPar, oVal);
                da.Fill(ds); da.Dispose(); da = null;
            }
            else
            {
                OleDbDataAdapter da = await FNFillRead(1, WSP, WPar, oVal);
                da.Fill(ds); da.Update(ds); da.Dispose(); da = null;
            }
            return ds;
        }
        public DataTable FNFillTableRep(string WSP, string WPar, params string[] oVal)
        {
            DataTable ds = new DataTable();
            if (SSAccDB == 0)
            {
                SqlDataAdapter da = FNLLenaTabla(WSP, WPar, oVal);
                da.Fill(ds); da.Dispose(); da = null;
            }
            else
            {
                OleDbDataAdapter da = FNLLenaTabla(1, WSP, WPar, oVal);
                da.Fill(ds); da.Update(ds); da.Dispose(); da = null;
            }
            return ds;
        }
        public DataSet FNFillTable(string WSP, string WPar, params string[] oVal)
        {
            DataSet ds = new DataSet();
            if (SSAccDB == 0)
            {
                SqlDataAdapter da = FNLLenaTabla(WSP, WPar, oVal);
                da.Fill(ds); da.Dispose(); da = null;
            }
            else
            {
                OleDbDataAdapter da = FNLLenaTabla(1, WSP, WPar, oVal);
                da.Fill(ds); da.Dispose(); da = null;
            }
            return ds;
        }
        public DataTable FNFillTable(int EsAccess, string WSP, string WPar, params string[] oVal)
        {
            DataTable ds = new DataTable();
            if (SSAccDB == 0)
            {
                SqlDataAdapter da = FNLLenaTabla(WSP, WPar, oVal);
                da.Fill(ds); da.Dispose(); da = null;
            }
            else
            {
                Thread.Sleep(1000);
                OleDbDataAdapter da = FNLLenaTabla(1, WSP, WPar, oVal);
                da.Fill(ds); da.Update(ds); da.Dispose(); da = null;
            }
            return ds;
        }
        private SqlDataAdapter FNLLenaTabla(string WSP, string WPar, params string[] oVal)
        {
            SqlCommand cmd = FNCMDExeSP(WSP, 1, WPar, oVal);
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            return da;
        }
        private OleDbDataAdapter FNLLenaTabla(int EsAccess, string WSP, string WPar, params string[] oVal)
        {
            OleDbCommand cmd = FNCMDExeSP(1, WSP, 1, WPar, oVal);
            OleDbDataAdapter da = new OleDbDataAdapter();
            da.SelectCommand = cmd;
            return da;
        }
        private async Task<SqlDataAdapter> FNFillRead(string WSP, string WPar, params string[] oVal)
        {
            SqlCommand cmd = FNCMDExeSP(WSP, 1, WPar, oVal);
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            return da;
        }        
        private async Task<OleDbDataAdapter> FNFillRead(int EsAccess, string WSP, string WPar, params string[] oVal)
        {
            OleDbCommand cmd = FNCMDExeSP(1, WSP, 1, WPar, oVal);
            OleDbDataAdapter da = new OleDbDataAdapter();
            da.SelectCommand = cmd;
            await Task.Delay(400);
            return da;
        }
        //BASE ENCRIP
        private int Asc(string WLet)
        {
            if (WLet.Length == 0) return 0;
            int nAsc = System.Convert.ToChar(WLet);
            return nAsc;
        }
        private String Hex(string WHnd)
        {
            int nWord = Convert.ToInt32(WHnd); string WHex = String.Format("{0:X}", nWord);
            return WHex;
        }
        public string FNCdHx(string WHnd)
        {
            String Wrd = ""; String WCar = ""; int nKey = 31; char CPad = '0';
            for (int J = 0; J <= WHnd.Length - 1; J++)
            {
                WCar = WHnd.Substring(J, 1); int nAsc = Asc(WCar) * nKey; string WHex = Hex(nAsc.ToString());
                Wrd = Wrd + WHex.PadLeft(4, CPad);
            }
            return Wrd;
        }
        public string FNDcHx(string WHnd)
        {
            String Wrd = ""; String WCar = ""; int nKey = 31; int J = 0;
            while (J < WHnd.Length)
            {
                WCar = WHnd.Substring(J, 4); string XCar = WCar; int nHNum = Int32.Parse(XCar, System.Globalization.NumberStyles.HexNumber); int nChr = nHNum / nKey; Wrd = Wrd + Convert.ToChar(nChr);
                J = J + 4;
            }
            return Wrd;
        }
        //BASE ENCRIP
        public void Dispose()
        {
            Dispose(true); GC.SuppressFinalize(this); GC.Collect(); GC.WaitForPendingFinalizers();
        }
        protected virtual void Dispose(bool disposing)
        {
            if (disposed) return;
            if (disposing)// Free any other managed objects here.
            {
            }// Free any unmanaged objects here.
            disposed = true; WMsg = ""; SSAccDB = -1;
            if (RD != null) RD = null;
        }
        ~DataLayer()
        {
            Dispose(false);
        }
    }
}